extends TextureButton

func _on_button_pressed():
	get_tree().change_scene_to_file("res://scenes/desert.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if button_pressed == true:
		_on_button_pressed()
